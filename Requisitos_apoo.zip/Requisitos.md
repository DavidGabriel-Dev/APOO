﻿![](Aspose.Words.e529234e-c52e-4b2f-91ef-efc588f069af.001.png)

**Requisitos**

Autor: David Gabriel Carneiro

Januária Outubro/2024

**Introdução**

A engenharia de requisitos é uma disciplina essencial para o desenvolvimento de sistemas de software, com foco na compreensão e definição precisa das necessidades e expectativas dos stakeholders. Conforme abordado no livro *Engenharia de Requisitos: Software Orientado ao Negócio*, essa área vai além da simples coleta de requisitos: envolve um processo interativo e colaborativo de elicitação, validação e gestão de requisitos ao longo de todo o ciclo de vida do projeto.

É importante notar, como destacado pelo livro, que os requisitos não são apenas de caráter técnico, mas também fortemente orientados ao negócio, refletindo as metas estratégicas e operacionais de cada organização. Assim, a engenharia de requisitos torna-se essencial para suprir as necessidades específicas do negócio, viabilizando soluções que melhor atendam aos objetivos por meio do software desenvolvido.

A obra também enfatiza a importância de uma comunicação clara e contínua entre todos os envolvidos na criação do software, desde os usuários finais até os desenvolvedores e designers. Essa comunicação é fundamental para evitar mal-entendidos futuros e garantir que cada requisito desejado seja capturado e implementado, de modo a maximizar a utilização do software para a empresa. Além disso, o livro explora técnicas e ferramentas para enfrentar a complexidade e as mudanças constantes dos requisitos, que muitas vezes acompanham ambientes de negócios dinâmicos.

Em resumo, uma aplicação eficaz da engenharia de requisitos não apenas contribui para o desenvolvimento de um software alinhado às necessidades da organização, mas também minimiza potenciais riscos que podem surgir ao longo do desenvolvimento.

**O que é a Engenharia de Requisitos?**

A engenharia de requisitos é uma disciplina essencial na engenharia de software, aplicando técnicas sistemáticas para atividades como obtenção, documentação e manutenção de requisitos. Esses requisitos devem estar alinhados aos objetivos de negócios da organização, assegurando que o software seja eficaz para alcançar essas metas. A qualidade dos requisitos é fundamental, pois afeta diretamente a funcionalidade, confiabilidade e usabilidade do sistema.

O termo "engenharia de requisitos" representa o uso sistemático de conhecimento técnico e científico, como em outras engenharias, para criar e melhorar sistemas de software. Esse processo estruturado permite que as necessidades dos clientes sejam compreendidas e atendidas continuamente.

Definida pela ISO, a engenharia de requisitos integra o conhecimento científico e tecnológico nas etapas de projeto, implementação, teste e documentação do software. Além disso, organiza habilidades específicas em áreas como análise, implementação e testes, promovendo uma interação contínua entre disciplinas para que o software atenda aos requisitos estabelecidos.

A aplicação da engenharia de requisitos varia conforme a estratégia de desenvolvimento adotada. Em ambientes mais rígidos, a falta de adaptação pode resultar em ciclos extensos de revisão e dificultar a entrega de software atualizado às necessidades do cliente. A engenharia de requisitos, bem aplicada, busca mitigar esses riscos, facilitando um entendimento contínuo e adaptação a novas demandas.

Essa disciplina também facilita a interação entre clientes e a equipe de desenvolvimento, ajudando a identificar e concordar nas soluções ideais. O processo inclui tarefas como análise de necessidades e documentação de requisitos, fornecendo uma base para outras atividades da engenharia de software, como projeto e testes.

**Requisitos**

O conceito de "requisito" é frequentemente confundido com "documentação", mas ele abrange muito mais do que isso e desempenha um papel central no desenvolvimento de software. Enquanto a documentação serve apenas para registrar os requisitos, estes são definidos como as condições ou capacidades necessárias para atender às expectativas dos usuários ou cumprir contratos.

A qualidade dos requisitos reflete a definição de Juran (1988), onde "qualidade é adequação ao uso", ou seja, os requisitos devem atender às necessidades dos usuários, ponto de partida essencial para qualquer definição de requisito. Além disso, requisitos englobam também as características que um produto existente deve possuir para cumprir normas e especificações.

É importante diferenciar entre "especificação de requisitos" (a documentação) e os próprios requisitos. Essa definição ampla, que incorpora necessidades, propriedades e documentação, é essencial para modelos de negócio e contratos em desenvolvimento de software. A especificação atua como um contrato entre clientes e equipe de desenvolvimento, detalhando expectativas de forma que ambos compreendam, ajudando a prevenir erros e garantir que o produto final atenda às expectativas.

Uma característica importante de uma especificação é ser "modificável" – mudanças devem ser realizadas de maneira completa e consistente, sem comprometer a estrutura. Isso evita omissões e inconsistências, que poderiam causar erros no projeto. Um exemplo típico é a dificuldade de atualizar múltiplos casos de uso ao adicionar uma nova funcionalidade, reforçando a necessidade de especificações bem estruturadas.

Outro critério essencial é a "rastreabilidade", que permite associar requisitos às suas origens e produtos derivados. Isso facilita mudanças, verificações de correção e completude, além de análises de impacto, garantindo que todos os objetivos de negócio sejam cumpridos e apoiando a gestão de riscos. Esses critérios de qualidade são cruciais para a elaboração da especificação, especialmente nas etapas de verificação e validação dos requisitos, que asseguram a qualidade do desenvolvimento.

**Importância da Engenharia de Requisitos**

A Engenharia de Requisitos é essencial para o sucesso dos projetos de software, estabelecendo a base para outras áreas da engenharia de software. Ignorar essa disciplina pode resultar em atrasos, custos extras, aumento de defeitos e na entrega de software que não atende completamente às necessidades do cliente.

Um exemplo marcante é a perda de uma sonda espacial devido a um erro de cálculo entre sistemas de medida imperial e métrico, evidenciando a importância de requisitos bem comunicados.

Uma empresa investiu em ferramentas e treinamento visando a produtividade, mas, sem foco adequado na Engenharia de Requisitos, seus projetos não atenderam às expectativas dos clientes, demonstrando que velocidade na produção não substitui uma boa definição de requisitos.

O Project Management Institute (PMI) aponta que 47% dos projetos falham devido a deficiências na Engenharia de Requisitos, levando a custos elevados, produtos insatisfatórios e retrabalho. Defeitos encontrados nas fases finais ou após a entrega são especialmente caros: Boehm (2001) mostra que corrigir erros pós-entrega pode custar até cem vezes mais do que em fases iniciais.

Documentar os requisitos é fundamental para preservar o conhecimento e mitigar os impactos da rotatividade de pessoal, funcionando como um ativo valioso para a continuidade do projeto.

Formação acadêmica e investimento em ferramentas nem sempre garantem a compreensão profunda da Engenharia de Requisitos. A falta de uma base sólida pode reduzir a eficácia das ferramentas e comprometer a qualidade dos projetos.

**Técnicas de Engenharia de Requisitos**

Na engenharia de requisitos, existem algumas técnicas que podem ser utilizadas para compreender as necessidades da empresa. Segundo o livro “Engenharia de Requisitos: Software Orientado ao Negócio”, cada técnica possui suas características, vantagens e desvantagens. As técnicas mais comuns citadas são:

1. **Diagramas e modelos**: O uso de diagramas e modelos (como casos de uso, diagramas de fluxo ou UML) ajuda a representar os requisitos e facilita a compreensão mútua entre analistas e stakeholders.
1. **Entrevistas**: Uma das técnicas mais tradicionais e eficazes, onde o analista realiza perguntas diretas às partes interessadas para extrair informações sobre os requisitos do sistema. As entrevistas podem ser estruturadas, semiestruturadas ou não estruturadas.
1. **Prototipagem**: Consiste no desenvolvimento de versões preliminares do sistema para ajudar as partes interessadas a visualizar o produto final. Essa técnica pode ser utilizada para esclarecer requisitos e descobrir necessidades ocultas.
1. **Revisão de documentos**: Inclui a análise de manuais, regulamentos e relatórios existentes para extrair informações relevantes sobre os requisitos.

**Considerações Finais**

Este livro enfatiza a importância de compreender o contexto do negócio onde o software será implementado, promovendo uma abordagem centrada no usuário e nas partes interessadas. Essa perspectiva é essencial para garantir que os requisitos coletados não apenas sejam viáveis tecnicamente, mas também relevantes para o negócio em questão.

O autor explora uma variedade de técnicas de elicitação, análise, documentação e validação dos requisitos, oferecendo ferramentas que podem se adaptar a diferentes tipos de projetos e contextos organizacionais. A combinação de cada técnica ajuda a construir uma compreensão clara e abrangente de cada requisito, minimizando riscos e aumentando as chances de sucesso do projeto.

Além disso, o livro incentiva a colaboração contínua entre equipes multidisciplinares, reforçando a ideia de que a engenharia de requisitos não é uma atividade isolada, mas um processo colaborativo e interativo.
